#!/usr/bin/env python3
"""LoRA SFT for C1 unified student modeling samples."""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
from typing import Any

os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")

import torch
from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training
from torch.utils.data import Dataset
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    BitsAndBytesConfig,
    DataCollatorForSeq2Seq,
    Trainer,
    TrainingArguments,
)


TARGET_MODULES = ["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"]
STATE_TOKEN = "<STUDENT_STATE>"
HISTORY_OPEN = "<student_history>"
BOTTLENECK_STYLES = ("standard", "late_fusion")


def add_special_state_token(tokenizer, state_token: str) -> bool:
    before = len(tokenizer)
    tokenizer.add_special_tokens({"additional_special_tokens": [state_token]})
    ids = tokenizer(state_token, add_special_tokens=False)["input_ids"]
    if len(ids) != 1:
        raise ValueError(f"{state_token} must tokenize to one id after registration, got {ids}")
    return len(tokenizer) > before


def resize_and_mean_init_new_tokens(model, tokenizer_len: int, old_vocab_size: int) -> None:
    if tokenizer_len <= old_vocab_size:
        return
    model.resize_token_embeddings(tokenizer_len)
    input_emb = model.get_input_embeddings()
    with torch.no_grad():
        old_weight = input_emb.weight[:old_vocab_size].detach()
        mean_row = old_weight.mean(dim=0, keepdim=True).to(input_emb.weight.dtype)
        input_emb.weight[old_vocab_size:tokenizer_len].copy_(mean_row)
        output_emb = model.get_output_embeddings()
        if output_emb is not None and output_emb.weight.shape[0] >= tokenizer_len:
            old_out = output_emb.weight[:old_vocab_size].detach()
            mean_out = old_out.mean(dim=0, keepdim=True).to(output_emb.weight.dtype)
            output_emb.weight[old_vocab_size:tokenizer_len].copy_(mean_out)


def read_jsonl(path: Path, limit: int | None = None, task_filter: str | None = None) -> list[dict[str, Any]]:
    rows = []
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            if line.strip():
                row = json.loads(line)
                if task_filter and row.get("task") != task_filter:
                    continue
                rows.append(row)
            if limit and len(rows) >= limit:
                break
    return rows


def find_bottleneck_positions(tokenizer, prompt: str) -> tuple[int, int]:
    state_char = prompt.find(STATE_TOKEN)
    if state_char < 0:
        raise ValueError(f"Could not find {STATE_TOKEN} in prompt")
    history_char = prompt.find(HISTORY_OPEN)
    if history_char < 0:
        raise ValueError(f"Could not find {HISTORY_OPEN} in prompt")
    history_start = len(tokenizer(prompt[:history_char], add_special_tokens=False)["input_ids"])
    state_pos = len(tokenizer(prompt[: state_char + len(STATE_TOKEN)], add_special_tokens=False)["input_ids"]) - 1
    if history_start >= state_pos:
        raise ValueError(f"Invalid bottleneck positions: history_start={history_start}, state_pos={state_pos}")
    return history_start, state_pos


def encode_example(
    tokenizer,
    row: dict[str, Any],
    max_length: int,
    supervise_eos: bool,
    bottleneck_mask: bool = False,
) -> dict[str, list[int] | int]:
    prefix = str(row["prompt"])
    target = str(row["target"])
    prefix_ids = tokenizer(prefix, add_special_tokens=False)["input_ids"]
    target_ids = tokenizer(target, add_special_tokens=False)["input_ids"]
    history_start, state_pos = (-1, -1)
    if bottleneck_mask:
        history_start, state_pos = find_bottleneck_positions(tokenizer, prefix)
    if not target_ids:
        raise ValueError(f"empty target for {row.get('example_id')}")
    add_eos = tokenizer.eos_token_id is not None
    max_prefix = max_length - len(target_ids) - int(add_eos)
    if max_prefix <= 0:
        raise ValueError(f"target too long for max_length={max_length}: {target}")
    if len(prefix_ids) > max_prefix:
        trim = len(prefix_ids) - max_prefix
        prefix_ids = prefix_ids[-max_prefix:]
        if bottleneck_mask:
            history_start -= trim
            state_pos -= trim
            if history_start < 0 or state_pos < 0:
                raise ValueError(f"Trimming removed bottleneck positions for {row.get('example_id')}")
    input_ids = prefix_ids + target_ids
    labels = [-100] * len(prefix_ids) + target_ids
    if add_eos:
        input_ids.append(tokenizer.eos_token_id)
        labels.append(tokenizer.eos_token_id if supervise_eos else -100)
    out: dict[str, list[int] | int] = {
        "input_ids": input_ids,
        "attention_mask": [1] * len(input_ids),
        "labels": labels,
    }
    if bottleneck_mask:
        out["history_start"] = history_start
        out["state_pos"] = state_pos
        out["prompt_end"] = len(prefix_ids)
    return out


def build_bottleneck_attention_mask(
    attention_2d: torch.Tensor,
    history_starts: torch.Tensor,
    state_positions: torch.Tensor,
    prompt_ends: torch.Tensor | None = None,
    style: str = "standard",
) -> torch.Tensor:
    if style not in BOTTLENECK_STYLES:
        raise ValueError(f"Unknown bottleneck style: {style}")
    batch_size, seq_len = attention_2d.shape
    device = attention_2d.device
    min_value = torch.finfo(torch.float32).min
    causal_block = torch.triu(torch.ones(seq_len, seq_len, device=device, dtype=torch.bool), diagonal=1)
    mask = torch.zeros((batch_size, 1, seq_len, seq_len), dtype=torch.float32, device=device)
    mask.masked_fill_(causal_block.view(1, 1, seq_len, seq_len), min_value)
    pad_cols = attention_2d.eq(0).view(batch_size, 1, 1, seq_len)
    mask.masked_fill_(pad_cols, min_value)
    for b in range(batch_size):
        h0 = int(history_starts[b].item())
        state_pos = int(state_positions[b].item())
        valid_len = int(attention_2d[b].sum().item())
        if not (0 <= h0 < state_pos < valid_len):
            raise ValueError(f"Invalid mask positions: h0={h0}, state_pos={state_pos}, valid_len={valid_len}")
        # Tokens after STATE must not attend to the history segment. The STATE
        # row itself remains unmasked so it can aggregate history.
        mask[b, 0, state_pos + 1 : valid_len, h0:state_pos] = min_value
        if style == "late_fusion":
            if prompt_ends is None:
                prompt_end = valid_len
            else:
                prompt_end = int(prompt_ends[b].item())
            if not (state_pos < prompt_end <= valid_len):
                raise ValueError(
                    f"Invalid prompt_end for late_fusion: state_pos={state_pos}, "
                    f"prompt_end={prompt_end}, valid_len={valid_len}"
                )
            # Keep question tokens pure: they encode the current problem but do
            # not read the student state. Target/answer tokens begin at
            # prompt_end and may attend to STATE, fusing problem + student.
            mask[b, 0, state_pos + 1 : prompt_end, state_pos] = min_value
    return mask


def build_causal_4d_attention_mask(attention_2d: torch.Tensor) -> torch.Tensor:
    batch_size, seq_len = attention_2d.shape
    device = attention_2d.device
    min_value = torch.finfo(torch.float32).min
    causal_block = torch.triu(torch.ones(seq_len, seq_len, device=device, dtype=torch.bool), diagonal=1)
    mask = torch.zeros((batch_size, 1, seq_len, seq_len), dtype=torch.float32, device=device)
    mask.masked_fill_(causal_block.view(1, 1, seq_len, seq_len), min_value)
    pad_cols = attention_2d.eq(0).view(batch_size, 1, 1, seq_len)
    mask.masked_fill_(pad_cols, min_value)
    return mask


def assert_bottleneck_mask(
    mask: torch.Tensor,
    history_start: int,
    state_pos: int,
    valid_len: int,
    prompt_end: int | None = None,
    style: str = "standard",
) -> None:
    blocked = mask[0, 0, state_pos + 1, history_start:state_pos]
    if not torch.isneginf(blocked).all() and not (blocked < -1e20).all():
        raise AssertionError("post-STATE row can still attend to history")
    allowed = mask[0, 0, state_pos, history_start:state_pos]
    if not torch.all(allowed == 0):
        raise AssertionError("STATE row cannot attend to history")
    future = mask[0, 0, :valid_len, :valid_len].triu(diagonal=1)
    if not torch.all((future == 0) | (future < -1e20)):
        raise AssertionError("mask has unexpected positive values")
    if style == "late_fusion":
        if prompt_end is None:
            raise AssertionError("late_fusion assertion requires prompt_end")
        q_blocked = mask[0, 0, state_pos + 1 : prompt_end, state_pos]
        if q_blocked.numel() and not (q_blocked < -1e20).all():
            raise AssertionError("question rows can still attend to STATE")
        if prompt_end < valid_len and mask[0, 0, prompt_end, state_pos] != 0:
            raise AssertionError("target rows cannot attend to STATE")


class BottleneckCollator:
    def __init__(self, tokenizer, style: str = "standard", mask_prob: float = 1.0) -> None:
        self.tokenizer = tokenizer
        self.style = style
        self.mask_prob = mask_prob
        self.pad_id = tokenizer.pad_token_id if tokenizer.pad_token_id is not None else tokenizer.eos_token_id
        if not (0.0 <= self.mask_prob <= 1.0):
            raise ValueError(f"mask_prob must be in [0, 1], got {self.mask_prob}")

    def __call__(self, features: list[dict[str, Any]]) -> dict[str, torch.Tensor]:
        max_len = max(len(feature["input_ids"]) for feature in features)
        input_ids, attention, labels, history_starts, state_positions, prompt_ends = [], [], [], [], [], []
        for feature in features:
            ids = list(feature["input_ids"])
            labs = list(feature["labels"])
            pad = max_len - len(ids)
            input_ids.append(ids + [self.pad_id] * pad)
            attention.append([1] * len(ids) + [0] * pad)
            labels.append(labs + [-100] * pad)
            history_starts.append(int(feature["history_start"]))
            state_positions.append(int(feature["state_pos"]))
            prompt_ends.append(int(feature["prompt_end"]))
        attention_2d = torch.tensor(attention, dtype=torch.long)
        history_tensor = torch.tensor(history_starts, dtype=torch.long)
        state_tensor = torch.tensor(state_positions, dtype=torch.long)
        prompt_end_tensor = torch.tensor(prompt_ends, dtype=torch.long)
        attention_mask = build_bottleneck_attention_mask(
            attention_2d, history_tensor, state_tensor, prompt_end_tensor, self.style
        )
        if self.mask_prob < 1.0:
            causal_mask = build_causal_4d_attention_mask(attention_2d)
            if self.mask_prob <= 0.0:
                attention_mask = causal_mask
            else:
                use_bottleneck = torch.rand(len(features), dtype=torch.float32).lt(self.mask_prob)
                selector = use_bottleneck.view(-1, 1, 1, 1).to(attention_mask.device)
                attention_mask = torch.where(selector, attention_mask, causal_mask)
        return {
            "input_ids": torch.tensor(input_ids, dtype=torch.long),
            "attention_mask": attention_mask,
            "labels": torch.tensor(labels, dtype=torch.long),
        }


class C1Dataset(Dataset):
    def __init__(
        self,
        path: Path,
        tokenizer,
        max_length: int,
        limit: int | None,
        supervise_eos: bool,
        task_filter: str | None = None,
        bottleneck_mask: bool = False,
    ) -> None:
        self.rows = read_jsonl(path, limit, task_filter)
        self.examples = [
            encode_example(tokenizer, row, max_length, supervise_eos, bottleneck_mask) for row in self.rows
        ]
        self.examples = [ex for ex in self.examples if any(label != -100 for label in ex["labels"])]
        if not self.examples:
            raise ValueError(f"No trainable examples from {path}")

    def __len__(self) -> int:
        return len(self.examples)

    def __getitem__(self, idx: int) -> dict[str, list[int]]:
        return self.examples[idx]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", required=True)
    parser.add_argument("--train-jsonl", type=Path, required=True)
    parser.add_argument("--valid-jsonl", type=Path)
    parser.add_argument("--task-filter")
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--max-length", type=int, default=2048)
    parser.add_argument("--max-train-samples", type=int, default=20000)
    parser.add_argument("--max-valid-samples", type=int, default=1500)
    parser.add_argument("--max-steps", type=int, default=200)
    parser.add_argument("--per-device-train-batch-size", type=int, default=2)
    parser.add_argument("--per-device-eval-batch-size", type=int, default=2)
    parser.add_argument("--gradient-accumulation-steps", type=int, default=16)
    parser.add_argument("--learning-rate", type=float, default=1e-4)
    parser.add_argument("--lora-rank", type=int, default=8)
    parser.add_argument("--lora-alpha", type=int, default=16)
    parser.add_argument("--lora-dropout", type=float, default=0.05)
    parser.add_argument("--load-4bit", action="store_true")
    parser.add_argument("--add-state-token", action="store_true")
    parser.add_argument("--state-token", default=STATE_TOKEN)
    parser.add_argument("--bottleneck-mask", action="store_true")
    parser.add_argument("--bottleneck-style", choices=BOTTLENECK_STYLES, default="standard")
    parser.add_argument(
        "--bottleneck-mask-prob",
        type=float,
        default=1.0,
        help="When bottleneck mask is enabled, randomly apply it to this fraction of training examples; "
        "the rest receive a standard causal 4D mask.",
    )
    parser.add_argument("--save-final-only", action="store_true")
    parser.add_argument("--supervise-eos", action="store_true")
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    tokenizer = AutoTokenizer.from_pretrained(args.model, trust_remote_code=True)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    base_tokenizer_len = len(tokenizer)
    added_state_token = False
    if args.add_state_token:
        added_state_token = add_special_state_token(tokenizer, args.state_token)
        state_id = tokenizer(args.state_token, add_special_tokens=False)["input_ids"][0]
        print(
            f"[train] state_token={args.state_token} state_id={state_id} "
            f"tokenizer_len={len(tokenizer)} added={added_state_token}",
            flush=True,
        )

    train_ds = C1Dataset(
        args.train_jsonl,
        tokenizer,
        args.max_length,
        args.max_train_samples,
        args.supervise_eos,
        args.task_filter,
        args.bottleneck_mask,
    )
    valid_ds = None
    if args.valid_jsonl:
        valid_ds = C1Dataset(
            args.valid_jsonl,
            tokenizer,
            args.max_length,
            args.max_valid_samples,
            args.supervise_eos,
            args.task_filter,
            args.bottleneck_mask,
        )

    quant = None
    if args.load_4bit:
        quant = BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_quant_type="nf4",
            bnb_4bit_compute_dtype=torch.bfloat16,
            bnb_4bit_use_double_quant=True,
        )
    model_kwargs = {}
    if args.bottleneck_mask:
        model_kwargs["attn_implementation"] = "eager"
    model = AutoModelForCausalLM.from_pretrained(
        args.model,
        trust_remote_code=True,
        quantization_config=quant,
        torch_dtype=torch.bfloat16 if torch.cuda.is_available() else torch.float32,
        device_map="auto" if torch.cuda.is_available() else None,
        **model_kwargs,
    )
    resize_and_mean_init_new_tokens(model, len(tokenizer), base_tokenizer_len)
    model.config.use_cache = False
    if args.load_4bit:
        model = prepare_model_for_kbit_training(model, use_gradient_checkpointing=True)
    modules_to_save = ["embed_tokens"] if args.add_state_token else None
    lora_cfg = LoraConfig(
        r=args.lora_rank,
        lora_alpha=args.lora_alpha,
        lora_dropout=args.lora_dropout,
        bias="none",
        task_type="CAUSAL_LM",
        target_modules=TARGET_MODULES,
        modules_to_save=modules_to_save,
    )
    model = get_peft_model(model, lora_cfg)
    model.print_trainable_parameters()

    if args.bottleneck_mask:
        first = train_ds[0]
        toy_attention = torch.tensor([first["attention_mask"]], dtype=torch.long)
        toy_mask = build_bottleneck_attention_mask(
            toy_attention,
            torch.tensor([int(first["history_start"])]),
            torch.tensor([int(first["state_pos"])]),
            torch.tensor([int(first["prompt_end"])]),
            args.bottleneck_style,
        )
        assert_bottleneck_mask(
            toy_mask,
            int(first["history_start"]),
            int(first["state_pos"]),
            int(sum(first["attention_mask"])),
            int(first["prompt_end"]),
            args.bottleneck_style,
        )
        print(
            f"[train] bottleneck mask enabled: style={args.bottleneck_style} "
            f"mask_prob={args.bottleneck_mask_prob} "
            f"history_start={first['history_start']} state_pos={first['state_pos']} "
            f"prompt_end={first['prompt_end']}",
            flush=True,
        )
        collator = BottleneckCollator(tokenizer, args.bottleneck_style, args.bottleneck_mask_prob)
    else:
        collator = DataCollatorForSeq2Seq(tokenizer=tokenizer, model=model, padding=True, label_pad_token_id=-100)
    training_args = TrainingArguments(
        output_dir=str(args.output_dir),
        seed=args.seed,
        max_steps=args.max_steps,
        per_device_train_batch_size=args.per_device_train_batch_size,
        per_device_eval_batch_size=args.per_device_eval_batch_size,
        gradient_accumulation_steps=args.gradient_accumulation_steps,
        learning_rate=args.learning_rate,
        warmup_steps=max(1, args.max_steps // 20),
        weight_decay=0.01,
        logging_steps=10,
        eval_strategy="steps" if valid_ds is not None else "no",
        eval_steps=max(25, args.max_steps // 4) if valid_ds is not None else None,
        save_strategy="no" if args.save_final_only else "steps",
        save_steps=max(50, args.max_steps // 2),
        save_total_limit=2,
        bf16=torch.cuda.is_available(),
        fp16=False,
        gradient_checkpointing=True,
        report_to=[],
        remove_unused_columns=False,
    )
    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=train_ds,
        eval_dataset=valid_ds,
        data_collator=collator,
        processing_class=tokenizer,
    )
    trainer.train()
    final_dir = args.output_dir / "final_adapter"
    trainer.save_model(str(final_dir))
    tokenizer.save_pretrained(final_dir)
    meta = {
        "model": args.model,
        "train_jsonl": str(args.train_jsonl),
        "valid_jsonl": str(args.valid_jsonl) if args.valid_jsonl else None,
        "task_filter": args.task_filter,
        "max_train_samples": args.max_train_samples,
        "max_valid_samples": args.max_valid_samples,
        "max_steps": args.max_steps,
        "add_state_token": args.add_state_token,
        "state_token": args.state_token if args.add_state_token else None,
        "added_state_token": added_state_token,
        "tokenizer_len": len(tokenizer),
        "save_final_only": args.save_final_only,
        "bottleneck_mask": args.bottleneck_mask,
        "bottleneck_style": args.bottleneck_style if args.bottleneck_mask else None,
        "bottleneck_mask_prob": args.bottleneck_mask_prob if args.bottleneck_mask else None,
    }
    (args.output_dir / "run_config.json").write_text(json.dumps(meta, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
